Ismael Resendiz Robles (i_r174)
A04929062

Assigment 4

Task 1: Skin detection evaluation modules

Results from evaluation 

	As the threshold value increases, the percentage of skin detection accuracy decreases, and on the contrary the accuracy in no-skin detection increases.

Module 1:
	From the plot curve, we can observe that this module performs best with a threshold 16.623314069294544
	Detecting skin max accuracy is 90.1%
	Detecting non-skin accuracy is 82.8%

Module 2:
	From the plot curve, we can observe that this module performs best with a threshold 18.009259642526956
	Detecting skin max accuracy is 89.4%
	Detecting non-skin accuracy is 83.2%

Module 3:
	From the plot curve, we can observe that this module performs best with a threshold 0.544945989902328 or 0.594368478798326
	For threshold value 0.544945989902328 
	Detecting skin max accuracy is 96.9%
	Detecting non-skin accuracy is 93.7%	
	
	For threshold value 0.594368478798326
	Detecting skin max accuracy is 95.8%
	Detecting non-skin accuracy is 98.8%

In conclusion, Module 3 "Histogram" outperforms the "Gaussian rg" Modules in this experiment.

Task 2: Histogram and evaluation
	The results show that the smaller bin size generate better accuracy to detect skin adn non-skin.
	Using threshold of 0.95, I obtained detection accuraacy of 98.7% skin and non-skin of 98%.