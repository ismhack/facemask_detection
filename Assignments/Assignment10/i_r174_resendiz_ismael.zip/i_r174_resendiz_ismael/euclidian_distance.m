function result = euclidian_distance(x, y)

result = sqrt((x(1)-y(1))^2+(x(2)-y(2))^2);
%result = abs(x(1) - x(2)) + abs(y(1) - y(2));

